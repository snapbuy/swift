//
//  Quote.swift
//  QuotesGenerator
//
//  Created by Gunter on 2021/08/14.
//

import Foundation

struct Quote {
  let contents: String
  let name: String
}
